var num = '10';
switch (num) {
    case 10:
        num++;
        break;
    case 5:
        num--;
        break;
    default:
        num = 0;
}
console.log(num);//=>0