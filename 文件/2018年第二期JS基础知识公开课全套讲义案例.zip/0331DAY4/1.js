for (var i = 0; i < 9; i++) {

    var sum = [i];
    sum.push("h");
    alert(sum);
}
