function fn() {
    var total = 10;
    total += 10;
    total = total.toFixed(2);
    console.log(total);
}