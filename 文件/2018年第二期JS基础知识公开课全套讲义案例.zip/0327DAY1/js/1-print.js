var num = 12;

/*快捷键：num.log TAB*/
console.log(num);