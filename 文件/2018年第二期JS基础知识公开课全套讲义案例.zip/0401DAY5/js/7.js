function fn() {
    var n = Math.PI;
    n *= 100;
    n = n.toFixed(2);//=>数字的方法，目的是保留小数点后面的位数
    console.log(n);
}
fn();
fn();
fn();





