var n = 10;
var m = n;
m = 20;
console.log(n); //=>10

var a = {name: '珠峰'};
var b = a;
b.name = '培训';
console.log(a.name); //=>'培训'